// Isi dari Supabase: Project Settings > API
window.CFG = {
  url: 'https://ISI-PROJECT-ID.supabase.co',
  key: 'ISI-ANON-PUBLIC-KEY',
  bucket: 'berkas',
  wa: '628xxxxxxxxxx'   // nomor WA Anda, format 62 tanpa + dan tanpa 0 di depan
};
